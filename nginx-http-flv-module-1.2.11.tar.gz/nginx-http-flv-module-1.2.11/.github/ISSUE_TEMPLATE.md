When you meet a bug, please open the issue including a title prefixed by '[bug]' and describe it as follows:
(当你碰到一个 bug，请在提出问题时以 '[bug]' 为前缀写明标题，并且像下面的内容一样描述它):

### Expected behavior (期望行为)

### Actual behavior (实际行为)

### OS and Nginx version (操作系统和 Nginx 版本号)

### Configuration file (配置文件)

### Steps to reproduce the behavior (复现问题步骤)

### Error log if any (错误日志)
